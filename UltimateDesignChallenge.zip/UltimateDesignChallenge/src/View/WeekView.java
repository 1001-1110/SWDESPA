package View;

public interface WeekView {

	public abstract void updateCurrent(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay);
	
}
