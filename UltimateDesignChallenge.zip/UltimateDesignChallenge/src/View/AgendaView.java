package View;
import java.util.List;

public interface AgendaView{
	
	public abstract int getSelectedOccasion();
	
}
