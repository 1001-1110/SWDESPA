package View;

public interface DayView {
	
	public abstract void updateCurrent(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay);

	public abstract void setFilters(boolean selected, boolean selected2);
	
}
