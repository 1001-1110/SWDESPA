package View;

import javax.swing.*;
import javax.swing.table.*;

import Entry.Book;
import Entry.Entries;
import Entry.EntriesCollection;
import Entry.EntriesIterator;
import Entry.Slot;

import java.awt.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.GroupLayout.Alignment;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AgendaProgramView extends JPanel implements AgendaView, ObserverView{
	
	CalendarView cv;
	
	List<Integer> rowAssignment;
	boolean freeFilter;
	boolean takenFilter;
	int currentRow;
	boolean weekView;
	Calendar c;
	Calendar c2;
	Calendar c3;
	Calendar c4;
	Calendar c5;
	Calendar c6;
	Calendar cEnd;
	
	JScrollPane scrollCalendarTable;    
	
        /**** Calendar Table Components ***/
	public JTable calendarTable;
    public DefaultTableModel modelCalendarTable;
    
    public void deselect() {
    	//currentRow = -1;
		//calendarTable.setDefaultRenderer(calendarTable.getColumnClass(0), new InfoTableRenderer(calendarTable.getSelectedRow()));    	
    }

    
    public void updateCurrent(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay, boolean weekView) {
    	c = new GregorianCalendar(currentSelectedYear,currentSelectedMonth,currentSelectedDay);
    	this.weekView = weekView;
    	if(weekView) {
    		c2 = new GregorianCalendar();
    		c2.setTime(c.getTime());
    		c2.add(Calendar.DATE, 1);
    		
    		c3 = new GregorianCalendar();
    		c3.setTime(c2.getTime());
    		c3.add(Calendar.DATE, 1);
    		
    		c4 = new GregorianCalendar();
    		c4.setTime(c3.getTime());
    		c4.add(Calendar.DATE, 1);
    		
    		c5 = new GregorianCalendar();
    		c5.setTime(c4.getTime());
    		c5.add(Calendar.DATE, 1);
    		
    		c6 = new GregorianCalendar();
    		c6.setTime(c5.getTime());
    		c6.add(Calendar.DATE, 1);
    		
    		cEnd = new GregorianCalendar();
    		cEnd.setTime(c6.getTime());
    		cEnd.add(Calendar.DATE, 1);
    		
    	}
    }    
    
    // WHERE YOU WILL IMPLEMENT HOW THE DATA IS DISPLAYED
    public void update(Entries slots, Entries books) {  	
    	//rowAssignment = where the IDs reside for referencing later on
		rowAssignment = new ArrayList<>();
		
		EntriesIterator eiSlots = slots.getIterator();
		EntriesIterator eiBooks = books.getIterator();
		if(!takenFilter) {
			Entries newSet = new EntriesCollection();
			while(eiSlots.hasNext()) {
				boolean taken = true;
				Slot slot = (Slot) eiSlots.next();
				eiBooks.reset();
				while(eiBooks.hasNext()) {
					Book book = (Book) eiBooks.next();
					if(checkTaken(slot,book)) {
						taken = false;
					}
				}
				if(taken) {
					newSet.add(slot);
				}
			}
			eiSlots = newSet.getIterator();
			slots = newSet;
		}
		eiSlots.reset();
		eiBooks.reset();
		
		if(!freeFilter) {
			Entries newSet = new EntriesCollection();
			while(eiSlots.hasNext()) {
				boolean taken = false;
				Slot slot = (Slot) eiSlots.next();
				eiBooks.reset();
				while(eiBooks.hasNext()) {
					Book book = (Book) eiBooks.next();
					if(checkTaken(slot,book)) {
						taken = true;
					}
				}
				if(taken) {
					newSet.add(slot);
				}
			}
			eiSlots = newSet.getIterator();
			slots = newSet;
		}	
		eiSlots.reset();
		eiBooks.reset();
		
		modelCalendarTable.setRowCount(0);
		Entries newSlots = new EntriesCollection();
		int row = 0;
		
		while(eiSlots.hasNext()) {
			Slot slot = (Slot) eiSlots.next();
			
			if(slot.getSlotType().equals("Single")) {
				row++;
				newSlots.add(slot);
			}else if(slot.getSlotType().equals("RecurWeek")) {
				System.out.println(weekView);
				if(weekView){
					row++;
					newSlots.add(slot);
				}else {
					if(slot.getDateFrom().get(Calendar.DAY_OF_WEEK) == c.get(Calendar.DAY_OF_WEEK)) {
						row++;
						newSlots.add(slot);
					}
				}
			}else if(slot.getSlotType().equals("RecurMonth")) {
				if(weekView){
					if(slot.getDateFrom().get(Calendar.DATE) == c.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c2.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c3.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c4.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c5.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c6.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == cEnd.get(Calendar.DATE)) {
								newSlots.add(slot);
								row++;
					}
								
				}else {
					if(slot.getDateFrom().get(Calendar.DATE) == c.get(Calendar.DATE)) {
						newSlots.add(slot);
						row++;
					}
				}				
			}else if(slot.getSlotType().equals("RecurYear")) {
				if(weekView){
					if(slot.getDateFrom().get(Calendar.DATE) == c.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c2.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c3.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c4.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c5.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == c6.get(Calendar.DATE)
							||slot.getDateFrom().get(Calendar.DATE) == cEnd.get(Calendar.DATE))
								if(slot.getDateFrom().get(Calendar.MONTH) == c.get(Calendar.MONTH)
								||slot.getDateFrom().get(Calendar.MONTH) == c2.get(Calendar.MONTH)
								||slot.getDateFrom().get(Calendar.MONTH) == c3.get(Calendar.MONTH)
								||slot.getDateFrom().get(Calendar.MONTH) == c4.get(Calendar.MONTH)
								||slot.getDateFrom().get(Calendar.MONTH) == c5.get(Calendar.MONTH)
								||slot.getDateFrom().get(Calendar.MONTH) == c6.get(Calendar.MONTH)
								||slot.getDateFrom().get(Calendar.MONTH) == cEnd.get(Calendar.MONTH)) {
									newSlots.add(slot);
									row++;
								}
				}else {
					if(slot.getDateFrom().get(Calendar.DATE) == c.get(Calendar.DATE) && slot.getDateFrom().get(Calendar.MONTH) == c.get(Calendar.MONTH)) {
						newSlots.add(slot);
						row++;
					}
				}			
			}
		}
		eiSlots = newSlots.getIterator();
		slots = newSlots;		
		
		if(freeFilter || takenFilter) {
			modelCalendarTable.setRowCount(row);
			while(eiSlots.hasNext()) {
				
				Slot slot = (Slot) eiSlots.next();
				
				String firstColumn = "<html>";
				String secondColumn = "<html>";
				String color = "green";
				String docColor = "black";

				if(slot.getDoctor().equals("Pau")) {
					docColor = "blue";
				}else if(slot.getDoctor().equals("Joanna")) {
					docColor = "orange";
				}
				
				eiBooks.reset();
				while(eiBooks.hasNext()) {
					Book book = (Book) eiBooks.next();
					if(checkTaken(slot,book)) {
						modelCalendarTable.setValueAt("<html>"+book.getClient()+"</html>", eiSlots.getPos()-1, 2);
						color = "red";
					}
				}		
				rowAssignment.add(slot.getId());
				
				if(slot.getSlotType().equals("Single")) {
					firstColumn += "<font color = "+color+">"+slot.getDurationFrom().substring(0,16)+" to "+slot.getDurationTo().substring(0,16)+"</html>";
					secondColumn += "<font color = "+docColor+">"+slot.getDoctor()+"</html>";
					modelCalendarTable.setValueAt(firstColumn, eiSlots.getPos()-1, 0);	
					modelCalendarTable.setValueAt(secondColumn, eiSlots.getPos()-1, 1);		
				}else if(slot.getSlotType().equals("RecurWeek")) {
					firstColumn += "<font color = "+color+">"+slot.getDurationFrom().substring(10,16)+" to "+slot.getDurationTo().substring(10,16)+" (Every week)"+"</html>";
					secondColumn += "<font color = "+docColor+">"+slot.getDoctor()+"</html>";
					modelCalendarTable.setValueAt(firstColumn, eiSlots.getPos()-1, 0);	
					modelCalendarTable.setValueAt(secondColumn, eiSlots.getPos()-1, 1);		
				}else if(slot.getSlotType().equals("RecurMonth")) {
					firstColumn += "<font color = "+color+">"+slot.getDurationFrom().substring(10,16)+" to "+slot.getDurationTo().substring(10,16)+" (Every month)"+"</html>";
					secondColumn += "<font color = "+docColor+">"+slot.getDoctor()+"</html>";
					modelCalendarTable.setValueAt(firstColumn, eiSlots.getPos()-1, 0);	
					modelCalendarTable.setValueAt(secondColumn, eiSlots.getPos()-1, 1);				
				}else if(slot.getSlotType().equals("RecurYear")) {
					firstColumn += "<font color = "+color+">"+slot.getDurationFrom().substring(10,16)+" to "+slot.getDurationTo().substring(10,16)+" (Every year)"+"</html>";
					secondColumn += "<font color = "+docColor+">"+slot.getDoctor()+"</html>";
					modelCalendarTable.setValueAt(firstColumn, eiSlots.getPos()-1, 0);	
					modelCalendarTable.setValueAt(secondColumn, eiSlots.getPos()-1, 1);			
				}

			}    			
		}
	    	
    }
    
    private boolean checkTaken(Slot slot, Book book) {
    	return (slot.getId() == book.getSlotsID() && slot.getDateFrom().get(Calendar.DAY_OF_WEEK) == book.getDateFrom().get(Calendar.DAY_OF_WEEK)
				&& slot.getDateFrom().get(Calendar.HOUR_OF_DAY) == book.getDateFrom().get(Calendar.HOUR_OF_DAY)
				&& slot.getDateFrom().get(Calendar.MINUTE) == book.getDateFrom().get(Calendar.MINUTE));
    }
    
    public void setFilters(boolean freeFilter, boolean takenFilter) {
    	this.freeFilter = freeFilter;
    	this.takenFilter = takenFilter;
    }
    
    public int getSelectedEntry() {
    	return rowAssignment.get(currentRow);
    }
    
	public AgendaProgramView(CalendarView cv){
		
		setBounds(0,0,620,440);
		
		this.cv =  cv;
		
		try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
		catch (Exception e) {}
        
		modelCalendarTable = new DefaultTableModel()
                {
                    public boolean isCellEditable(int rowIndex, int mColIndex)
                    {
                        return false;
                    }
                };      
                
		calendarTable = new JTable(modelCalendarTable);
		calendarTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				currentRow = (int) calendarTable.getSelectedRow();
				calendarTable.setDefaultRenderer(calendarTable.getColumnClass(0), new InfoTableRenderer(calendarTable.getSelectedRow()));
				cv.enableSelectButtons();
				calendarTable.clearSelection();
				calendarTable.repaint();
			}
		});
                
		scrollCalendarTable = new JScrollPane(calendarTable);
		scrollCalendarTable.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		this.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		calendarTable.getParent().setBackground(calendarTable.getBackground()); //Set background

		calendarTable.getTableHeader().setResizingAllowed(false);
		calendarTable.getTableHeader().setReorderingAllowed(false);

		calendarTable.setColumnSelectionAllowed(true);
		calendarTable.setRowSelectionAllowed(true);
		calendarTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		calendarTable.setRowHeight(20);
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollCalendarTable, GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollCalendarTable, GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
					.addContainerGap())
		);
		setLayout(groupLayout);
		modelCalendarTable.addColumn("Time");
		modelCalendarTable.addColumn("Doctor");
		modelCalendarTable.addColumn("Client");

		calendarTable.setDefaultRenderer(calendarTable.getColumnClass(0), new InfoTableRenderer(calendarTable.getSelectedRow()));
	}
}
