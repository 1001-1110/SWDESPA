package View;

import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import Entry.Book;
import Entry.Entries;
import Entry.EntriesCollection;
import Entry.EntriesIterator;
import Entry.Entry;
import Entry.Slot;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

import javax.swing.GroupLayout.Alignment;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class DayProgramView extends JPanel implements DayView, ObserverView{

	CalendarView cv;
	
	private int currentSelectedMonth, currentSelectedDay, currentSelectedYear;
	private Calendar c;
	boolean freeFilter;
	boolean takenFilter;
	
	JScrollPane scrollCalendarTable;    
	
        /**** Calendar Table Components ***/
	public JTable calendarTable;
    public DefaultTableModel modelCalendarTable;

    public void deselect() {
    	
    }
    
    public void updateCurrent(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay) {
    	this.currentSelectedYear = currentSelectedYear;
    	this.currentSelectedMonth = currentSelectedMonth;
    	this.currentSelectedDay = currentSelectedDay;
    	String[] dayNames = {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};
    	c = new GregorianCalendar(currentSelectedYear,currentSelectedMonth,currentSelectedDay);
		this.setBorder(new TitledBorder(null, dayNames[c.get(Calendar.DAY_OF_WEEK)-1], TitledBorder.LEADING, TitledBorder.TOP, null, null));
    }
    
    // WHERE YOU WILL IMPLEMENT HOW THE DATA IS DISPLAYED
    public void update(Entries slots, Entries books) {  	
    	//rowAssignment = where the IDs reside for referencing later on
		
		EntriesIterator eiSlots = slots.getIterator();
		EntriesIterator eiBooks = books.getIterator();
		
		Entries newSlots = new EntriesCollection();
		Entries newBooks = new EntriesCollection();

		while(eiSlots.hasNext()) {
			Slot slot = (Slot) eiSlots.next();
			
			if(slot.getSlotType().equals("Single")) {
				if(slot.getDateFrom().get(Calendar.YEAR) == c.get(Calendar.YEAR)
						&& slot.getDateFrom().get(Calendar.MONTH) == c.get(Calendar.MONTH)
						&& slot.getDateFrom().get(Calendar.DATE) == c.get(Calendar.DATE)) {
					newSlots.add(slot);
				}
			}else if(slot.getSlotType().equals("RecurWeek")) {
				if(slot.getDateFrom().get(Calendar.DAY_OF_WEEK) == c.get(Calendar.DAY_OF_WEEK)) {
					Calendar newDateFrom = new GregorianCalendar(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DATE),slot.getDateFrom().get(Calendar.HOUR_OF_DAY),slot.getDateFrom().get(Calendar.MINUTE));
					Calendar newDateTo = new GregorianCalendar(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DATE),slot.getDateTo().get(Calendar.HOUR_OF_DAY),slot.getDateTo().get(Calendar.MINUTE));
					slot = new Slot(slot.getDoctor(), slot.getSlotType(), newDateFrom, newDateTo, slot.getDurationFrom(), slot.getDurationTo(), slot.getId());
					newSlots.add(slot);
				}
			}else if(slot.getSlotType().equals("RecurMonth")) {
				if(slot.getDateFrom().get(Calendar.DATE) == c.get(Calendar.DATE)) {
					Calendar newDateFrom = new GregorianCalendar(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DATE),slot.getDateFrom().get(Calendar.HOUR_OF_DAY),slot.getDateFrom().get(Calendar.MINUTE));
					Calendar newDateTo = new GregorianCalendar(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DATE),slot.getDateTo().get(Calendar.HOUR_OF_DAY),slot.getDateTo().get(Calendar.MINUTE));
					slot = new Slot(slot.getDoctor(), slot.getSlotType(), newDateFrom, newDateTo, slot.getDurationFrom(), slot.getDurationTo(), slot.getId());
					newSlots.add(slot);
				}			
			}else if(slot.getSlotType().equals("RecurYear")) {
				if(slot.getDateFrom().get(Calendar.DATE) == c.get(Calendar.DATE) && slot.getDateFrom().get(Calendar.MONTH) == c.get(Calendar.MONTH)) {
					Calendar newDateFrom = new GregorianCalendar(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DATE),slot.getDateFrom().get(Calendar.HOUR_OF_DAY),slot.getDateFrom().get(Calendar.MINUTE));
					Calendar newDateTo = new GregorianCalendar(c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DATE),slot.getDateTo().get(Calendar.HOUR_OF_DAY),slot.getDateTo().get(Calendar.MINUTE));
					slot = new Slot(slot.getDoctor(), slot.getSlotType(), newDateFrom, newDateTo, slot.getDurationFrom(), slot.getDurationTo(), slot.getId());
					newSlots.add(slot);
				}		
			}
		}
		eiSlots = newSlots.getIterator();
		slots = newSlots;		

		while(eiBooks.hasNext()) {
			Book book = (Book) eiBooks.next();
			if(book.getDateFrom().get(Calendar.YEAR) == c.get(Calendar.YEAR)
					&& book.getDateFrom().get(Calendar.MONTH) == c.get(Calendar.MONTH)
					&& book.getDateFrom().get(Calendar.DATE) == c.get(Calendar.DATE)) {
				newBooks.add(book);
			}
		}
		
		eiSlots = newSlots.getIterator();
		eiBooks = newBooks.getIterator();
		slots = newSlots;
		books = newBooks;
		
		modelCalendarTable.setRowCount(0);
		
		eiSlots.orderByDateAscending();
		
		eiSlots.reset();
		
		if(eiSlots.first() != null) {
			Calendar firstDate = new GregorianCalendar();
			firstDate.set(Calendar.HOUR_OF_DAY, eiSlots.first().getDateFrom().get(Calendar.HOUR_OF_DAY));
			firstDate.set(Calendar.MINUTE, eiSlots.first().getDateFrom().get(Calendar.MINUTE));
			Calendar lastDate = new GregorianCalendar();
			lastDate.set(Calendar.HOUR_OF_DAY, eiSlots.last().getDateFrom().get(Calendar.HOUR_OF_DAY));
			lastDate.set(Calendar.MINUTE, eiSlots.last().getDateFrom().get(Calendar.MINUTE));
			Calendar usedFirstDate = new GregorianCalendar();
			usedFirstDate.set(Calendar.HOUR_OF_DAY, eiSlots.first().getDateFrom().get(Calendar.HOUR_OF_DAY));
			usedFirstDate.set(Calendar.MINUTE, eiSlots.first().getDateFrom().get(Calendar.MINUTE));
			Calendar usedLastDate = new GregorianCalendar();
			usedLastDate.set(Calendar.HOUR_OF_DAY, eiSlots.last().getDateFrom().get(Calendar.HOUR_OF_DAY));
			usedLastDate.set(Calendar.MINUTE, eiSlots.last().getDateFrom().get(Calendar.MINUTE));
			
			if(!takenFilter) {
				Entries newSet = new EntriesCollection();
				while(eiSlots.hasNext()) {
					boolean taken = true;
					Slot slot = (Slot) eiSlots.next();
					eiBooks.reset();
					while(eiBooks.hasNext()) {
						Book book = (Book) eiBooks.next();
						if(checkTaken(slot,book)) {
							taken = false;
						}
					}
					if(taken) {
						newSet.add(slot);
					}
				}
				eiSlots = newSet.getIterator();
				slots = newSet;
			}
			eiSlots.reset();
			eiBooks.reset();
			
			if(!freeFilter) {
				Entries newSet = new EntriesCollection();
				while(eiSlots.hasNext()) {
					boolean taken = false;
					Slot slot = (Slot) eiSlots.next();
					eiBooks.reset();
					while(eiBooks.hasNext()) {
						Book book = (Book) eiBooks.next();
						if(checkTaken(slot,book)) {
							taken = true;
						}
					}
					if(taken) {
						newSet.add(slot);
					}
				}
				eiSlots = newSet.getIterator();
				slots = newSet;
			}	
			eiSlots.reset();
			eiBooks.reset();
			
			int rowCount = 0;
			lastDate.add(Calendar.MINUTE, 30);
			while(firstDate.before(lastDate)) {
				rowCount++;
				firstDate.add(Calendar.MINUTE, 30);
			}
			
			modelCalendarTable.setRowCount(rowCount);
			
			if(freeFilter || takenFilter) {

				int row = 0;
				usedLastDate.add(Calendar.MINUTE, 30);

				while(usedFirstDate.before(usedLastDate)) {
					
					String hour = new String();
					String minute = new String();
					
					if(usedFirstDate.get(Calendar.HOUR_OF_DAY)<10) {
						hour += "0";
					}
					if(usedFirstDate.get(Calendar.MINUTE)<10) {
						minute += "0";
					}
					
					hour += usedFirstDate.get(Calendar.HOUR_OF_DAY);
					minute += usedFirstDate.get(Calendar.MINUTE);

					String currentTime = hour+":"+minute;
					
					eiSlots.reset();
					boolean slotTaken = false;
					String color = null;
					
					while(eiSlots.hasNext()) {
						Entry slot = eiSlots.next();
						
						if(color == null)
							color = "green";
						
						if(slot.getDateFrom().get(Calendar.HOUR_OF_DAY) == usedFirstDate.get(Calendar.HOUR_OF_DAY) 
								&& slot.getDateFrom().get(Calendar.MINUTE) == usedFirstDate.get(Calendar.MINUTE)){
								
							String firstColumn = "<html>";
							String doctorColumn = "<html>";
							String docColor = "black";
		
							if(((Slot) slot).getDoctor().equals("Pau")) {
								docColor = "blue";
							}else if(((Slot) slot).getDoctor().equals("Joanna")) {
								docColor = "orange";
							}			
							
							eiBooks.reset();	
							while(eiBooks.hasNext()) {
								Book book = (Book) eiBooks.next();
								if(slot.getId() == book.getSlotsID()) {
									modelCalendarTable.setValueAt("<html>"+book.getClient()+"</html>",row, 3);
									doctorColumn += "<b>";
									color = "red";
								}
							}
							
							firstColumn += "<font color = "+color+">"+currentTime;
							doctorColumn += "<font color = "+docColor+">"+((Slot) slot).getDoctor()+"</html>";	
							
							if(((Slot) slot).getDoctor().equals("Pau")){
								modelCalendarTable.setValueAt(doctorColumn, row, 1);
								modelCalendarTable.setValueAt(firstColumn, row, 0);	
								slotTaken = true;
							}else if(((Slot) slot).getDoctor().equals("Joanna")) {
								modelCalendarTable.setValueAt(doctorColumn, row, 2);
								modelCalendarTable.setValueAt(firstColumn, row, 0);	
								slotTaken = true;
							}
								
						}
					}
					
					if(!slotTaken) {
						modelCalendarTable.setValueAt(currentTime, row, 0);
					}
					
					usedFirstDate.add(Calendar.MINUTE, 30);
					row++;

				}    			
			}
		}

    }
    
    private boolean checkTaken(Slot slot, Book book) {
    	return (slot.getId() == book.getSlotsID() && slot.getDateFrom().get(Calendar.DAY_OF_WEEK) == book.getDateFrom().get(Calendar.DAY_OF_WEEK)
				&& slot.getDateFrom().get(Calendar.HOUR_OF_DAY) == book.getDateFrom().get(Calendar.HOUR_OF_DAY)
				&& slot.getDateFrom().get(Calendar.MINUTE) == book.getDateFrom().get(Calendar.MINUTE));
    }
    
    public void setFilters(boolean freeFilter, boolean takenFilter) {
    	this.freeFilter = freeFilter;
    	this.takenFilter = takenFilter;
    }
    
	public DayProgramView(CalendarView cv){
		
		setBounds(0,0,620,440);

		this.cv = cv;
		
		try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
		catch (Exception e) {}
        
		modelCalendarTable = new DefaultTableModel()
                {
                    public boolean isCellEditable(int rowIndex, int mColIndex)
                    {
                        return false;
                    }
                };      
                
		calendarTable = new JTable(modelCalendarTable);
                
		scrollCalendarTable = new JScrollPane(calendarTable);
		scrollCalendarTable.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		calendarTable.getParent().setBackground(calendarTable.getBackground()); //Set background

		calendarTable.getTableHeader().setResizingAllowed(false);
		calendarTable.getTableHeader().setReorderingAllowed(false);
		calendarTable.setRowSelectionAllowed(false);
		calendarTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		calendarTable.setRowHeight(20);
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollCalendarTable, GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollCalendarTable, GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
					.addContainerGap())
		);
		setLayout(groupLayout);
		modelCalendarTable.addColumn("Time");
		modelCalendarTable.addColumn("Doctor");
		modelCalendarTable.addColumn("Doctor");
		modelCalendarTable.addColumn("Client");
		
		calendarTable.setDefaultRenderer(calendarTable.getColumnClass(0), new InfoTableRenderer(calendarTable.getSelectedRow()));
	}
}
