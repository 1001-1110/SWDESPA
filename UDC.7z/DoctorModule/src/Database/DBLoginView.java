package Database;

import Database.Database;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class DBLoginView extends JFrame{
	
	boolean unLogged = true;
	private JTextField url;
	private JTextField user;
	private JTextField pass;
	
	public DBLoginView() {
		super("Database Login");
		initialize();
		setVisible(true);
	}

	private void initialize() {
		setBounds(100, 100, 450, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblNewLabel = new JLabel("Database URL:");
		
		JLabel lblNewLabel_1 = new JLabel("Database Username:");
		
		JLabel lblNewLabel_2 = new JLabel("Database Password:");
		
		url = new JTextField();
		url.setText("112.205.74.172");
		url.setColumns(10);
		
		user = new JTextField();
		user.setText("superuser");
		user.setColumns(10);
		
		pass = new JTextField();
		pass.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//jdbc:mysql://127.0.0.1:3306/
				String URL = "jdbc:mysql://"+url.getText()+":3306/";
				String USERNAME = user.getText();
				String PASSWORD = pass.getText();
				String DATABASE = "swdespa";
				unLogged = !Database.getInstance().setConnection(URL, USERNAME, PASSWORD, DATABASE);
			}
		});
		pass.setText("sophia");
		pass.setColumns(10);
		
		JButton btnLogin = new JButton("Login");
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//jdbc:mysql://127.0.0.1:3306/
				String URL = "jdbc:mysql://"+url.getText()+":3306/";
				String USERNAME = user.getText();
				String PASSWORD = pass.getText();
				String DATABASE = "swdespa";
				unLogged = !Database.getInstance().setConnection(URL, USERNAME, PASSWORD, DATABASE);
			}
		});
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(46)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(url, GroupLayout.PREFERRED_SIZE, 204, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_1)
							.addGap(18)
							.addComponent(user, GroupLayout.PREFERRED_SIZE, 204, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_2)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(btnLogin)
								.addComponent(pass, GroupLayout.PREFERRED_SIZE, 204, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap(65, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(51)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(url, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(user, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(pass, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(45)
					.addComponent(btnLogin)
					.addContainerGap(47, Short.MAX_VALUE))
		);
		getContentPane().setLayout(groupLayout);
	}

	public boolean login() {
		try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(!unLogged) {
			this.dispose();
		}
		return unLogged;
	}
}
