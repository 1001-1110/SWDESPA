package Entry;

import java.util.Calendar;

public class Notif extends Entry{

	String client;
	String doctor;
	
	public String getClient() {
		return client;
	}

	public String getDoctor() {
		return doctor;
	}

	public Notif(Calendar dateFrom, Calendar dateTo, String durationFrom, String durationTo, String client, String doctor, int id) {
		super(dateFrom, dateTo, durationFrom, durationTo, id);
		this.client = client;
		this.doctor = doctor;
		// TODO Auto-generated constructor stub
	}

}
