package Entry;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.List;

public class EntriesIterator implements Iterator<Entry> {
    private List<Entry> entries;
    private int pos = 0;

    public EntriesIterator(List<Entry> entries) {
        this.entries = entries;
    }

    public Entry peek() {
    	Entry entry = entries.get(pos);
    	return entry;
    }
    
    public int getPos() {
    	return pos;
    }
    
    public void remove() {
		try {
			entries.remove(pos);	
		}catch(IndexOutOfBoundsException e) {}
    }
    
    public void remove(Entry entry) {
		try {
			entries.remove(entry);	
		}catch(IndexOutOfBoundsException e) {}
    }
    
    public void reset() {
    	pos = 0;
    }
    
    public void orderByDateAscending() {
    	Calendar c = new GregorianCalendar();
    	List<Entry> newEntries = new ArrayList<>();
    	Entry entry;
    	int initialSize = entries.size();

    	for(int j = 0; j < initialSize; j++) {
        	c.setTime(entries.get(0).getDateFrom().getTime());
        	entry = entries.get(0);
        	for(int i = 0 ; i < entries.size() ; i++) {
        		if(c.getTime().after(entries.get(i).getDateFrom().getTime())) { 
        			c = entries.get(i).getDateFrom();
        			entry = entries.get(i);
        		}
        	}
        	newEntries.add(entry);
        	entries.remove(entry);
    	}
    	entries = newEntries;
    }    
    
    public Entry first() {
    	if(entries.size() > 0)
    		return entries.get(0);
    	else
    		return null;
    }
    
    public Entry last() {
    	if(entries.size() > 0)
        	return entries.get(entries.size()-1);
    	else
    		return null;
    }    
    
	public Entry next() {
		Entry entry = null;
		try {
			entry = entries.get(pos);
		}catch(NullPointerException e) {	
		}catch(IndexOutOfBoundsException e) {}

		pos += 1;
		return entry;
	}
 
	public boolean hasNext() {
		if (pos >= entries.size() || entries.get(pos) == null) {
			return false;
		} else {
			return true;
		}
	}
}