package DoctorView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import View.CalendarProgramView;
import View.CalendarView;
import java.awt.Color;

public class DoctorSlotEditorProgramView extends JFrame implements DoctorSlotAdderView {

	private CalendarView cv;
	
	
	private JPanel contentPane;
	private JButton btnSave;
	private JButton btnDiscard;
	private JTextField txtDateStart;
	private JTextField txtTimeStart;
	private JTextField txtTimeEnd;
	private JLabel lblDateMm;
	private JLabel lblNewLabel;
	private JLabel lblToTime;
	private JLabel lblEditLabel;


	/**
	 * Create the frame.
	 */
	public DoctorSlotEditorProgramView(CalendarView cv) {
		this.cv = cv;
		//comment out initialize when running the Main DesignChallenge
//		initialize();
	}
	
	public void initialize() {
		setTitle("Doctor Slot Editor");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnSave = new JButton("Save & Edit");
		btnSave.setBackground(new Color(30, 144, 255));
		btnSave.setForeground(new Color(30, 144, 255));
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//send input to control
				
//				String type = "single";
//				if(rdbtnRepeating.isSelected()) {
//					type = "recur";
//				}
				
				int id[] = {((CalendarProgramView) cv).getAgendaView().getSelectedEntry()};
				
				if(((CalendarProgramView) cv).getController().checkSlots(cv.getDoctorName(), txtDateStart.getText(), 
						txtDateStart.getText(), txtTimeStart.getText(), txtTimeEnd.getText(), "single")) {
					if(((CalendarProgramView) cv).getController().freeUpSlots(id) && ((CalendarProgramView) cv).getController().addSlots(cv.getDoctorName(), txtDateStart.getText(), 
							txtDateStart.getText(), txtTimeStart.getText(), txtTimeEnd.getText(), "single")) {
						lblEditLabel.setText("<html><font color = green>Edit Successful</font></html>");
					}else {
						JOptionPane.showMessageDialog(null, "Cannot edit this entry.", "Error", JOptionPane.ERROR_MESSAGE);
						lblEditLabel.setText("<html><font color = red>Edit Unsuccessful</font></html>");
					}
				}else {
					JOptionPane.showMessageDialog(null, "Cannot edit this entry.", "Error", JOptionPane.ERROR_MESSAGE);
					lblEditLabel.setText("<html><font color = red>Edit Unsuccessful</font></html>");
				}

//				txtDateStart.setText(null);
				txtTimeStart.setText(null);
				txtTimeEnd.setText(null);
				//sets the save label to true
				lblEditLabel.setVisible(true);
			}
		});
		btnSave.setBounds(131, 183, 99, 23);
		contentPane.add(btnSave);
		
		btnDiscard = new JButton("Clear");
		btnDiscard.setForeground(new Color(30, 144, 255));
		btnDiscard.setBackground(new Color(30, 144, 255));
		btnDiscard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				txtDateStart.setText(null);
				txtTimeStart.setText(null);
				txtTimeEnd.setText(null);
//				setVisible(false);
				lblEditLabel.setVisible(false);
			}
		});
		btnDiscard.setBounds(236, 183, 72, 23);
		contentPane.add(btnDiscard);
		
		txtDateStart = new JTextField();
		txtDateStart.setBounds(132, 77, 176, 20);
		contentPane.add(txtDateStart);
		txtDateStart.setColumns(10);
		
		txtTimeStart = new JTextField();
		txtTimeStart.setBounds(132, 122, 72, 20);
		contentPane.add(txtTimeStart);
		txtTimeStart.setColumns(10);
		
		txtTimeEnd = new JTextField();
		txtTimeEnd.setBounds(229, 122, 79, 20);
		contentPane.add(txtTimeEnd);
		txtTimeEnd.setColumns(10);
		
		lblDateMm = new JLabel("Date (MM/DD/YYYY):");
		lblDateMm.setBounds(11, 80, 111, 14);
		contentPane.add(lblDateMm);
		
		lblNewLabel = new JLabel("Time (24 hour): ");
		lblNewLabel.setBounds(37, 125, 93, 14);
		contentPane.add(lblNewLabel);
		
		lblToTime = new JLabel("to:");
		lblToTime.setBounds(210, 125, 20, 14);
		contentPane.add(lblToTime);
		
		//added the save successful button
		lblEditLabel = new JLabel("Edit Successful!");
		lblEditLabel.setVisible(false);
		lblEditLabel.setBounds(178, 217, 111, 14);
		contentPane.add(lblEditLabel);
		
		
	}
	
	public void clearInputs() {
		txtDateStart.setText(null);
		txtTimeStart.setText(null);
		txtTimeEnd.setText(null);
	}
	
	public void updateCurrentDate(int currentSelectedMonth,int currentSelectedDay, int currentSelectedYear) {
		txtDateStart.setText(currentSelectedMonth+1+"/"+currentSelectedDay+"/"+currentSelectedYear);
	}
	
	public JTextField getTxtDateStart() {
		return txtDateStart;
	}

	@Override
	public void hideLabel() {
		// TODO Auto-generated method stub
		lblEditLabel.setText(null);
	}

}
