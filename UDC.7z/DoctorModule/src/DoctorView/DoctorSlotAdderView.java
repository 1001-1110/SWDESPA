package DoctorView;

public interface DoctorSlotAdderView {
	public abstract void clearInputs();
	
	public abstract void initialize();
	
	public abstract void updateCurrentDate(int currentSelectedMonth, int currentSelectedDay, int currentSelectedYear);
	
	public abstract void hideLabel();
}
