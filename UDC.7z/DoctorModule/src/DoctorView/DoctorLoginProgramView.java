package DoctorView;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import View.CalendarProgramView;
import View.CalendarView;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class DoctorLoginProgramView extends JFrame implements DoctorLoginView{

	private JPanel contentPane;
	private JTextField usernameField;
	private JPasswordField passwordField;
	private CalendarView cpv;
//	private DoctorProgramModel dpm;
//	private DoctorProgramControl dpc;

	public DoctorLoginProgramView(CalendarView cpv) {
		super("Doctor Login");
		this.cpv = cpv;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 392, 234);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		usernameField = new JTextField();
//		usernameField.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				if("DoctorPau".equalsIgnoreCase(usernameField.getText()) || "DoctorJoanne".equalsIgnoreCase(usernameField.getText())) {
//					//login
//					System.out.println("Tst");
//					JOptionPane.showMessageDialog(null, "Login Successful");
//				}else {
//					JOptionPane.showMessageDialog(null, "Doctor not identified, please try again.");
//				}
//			}
//		});
		usernameField.setBounds(101, 55, 237, 20);
		contentPane.add(usernameField);
		usernameField.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!usernameField.getText().trim().equals("")) {
					if("password".equalsIgnoreCase(new String(passwordField.getPassword()))) {
						//login
						setVisible(false);
						JOptionPane.showMessageDialog(null, "Login Successful");
						((CalendarProgramView)cpv).frmMain.setVisible(true);
						((CalendarProgramView)cpv).getLblTitle().setText(usernameField.getText());
						((CalendarProgramView)cpv).setDoctorName(usernameField.getText());
						//send name to control/ model
					}else {
						JOptionPane.showMessageDialog(null, "Wrong Password, please try again.");
					}
				}else {
					JOptionPane.showMessageDialog(null, "Username cannot be empty.");
				}
			}
		});
		passwordField.setBounds(101, 102, 237, 20);
		contentPane.add(passwordField);
		
		JLabel lblUsername = new JLabel("Username: ");
		lblUsername.setBounds(10, 57, 81, 17);
		contentPane.add(lblUsername);
		
		JLabel lblPassword = new JLabel("Password:");
		lblPassword.setBounds(10, 105, 81, 14);
		contentPane.add(lblPassword);
		
		
		
		JButton btnLogin = new JButton("Login");
		btnLogin.setForeground(new Color(30, 144, 255));
		btnLogin.setBackground(new Color(30, 144, 255));
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!usernameField.getText().trim().equals("")) {
					if("password".equalsIgnoreCase(new String(passwordField.getPassword()))) {
						//login
						setVisible(false);
						JOptionPane.showMessageDialog(null, "Login Successful");
						((CalendarProgramView)cpv).frmMain.setVisible(true);
						((CalendarProgramView)cpv).getLblTitle().setText(usernameField.getText());
						((CalendarProgramView)cpv).setDoctorName(usernameField.getText());
						//send name to control/ model
					}else {
						JOptionPane.showMessageDialog(null, "Wrong Password, please try again.");
					}
				}else {
					JOptionPane.showMessageDialog(null, "Username cannot be empty.");
				}
			}
		});
		btnLogin.setBounds(136, 161, 89, 23);
		contentPane.add(btnLogin);
		
		setVisible(true);
	}
}
