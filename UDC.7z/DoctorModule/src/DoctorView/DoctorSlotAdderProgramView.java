package DoctorView;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import View.CalendarProgramView;
import View.CalendarView;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JComboBox;

public class DoctorSlotAdderProgramView extends JFrame implements DoctorSlotAdderView{

//	private DoctorProgramModel dpm;
//	private DoctorProgramControl dpc;
	private CalendarView cv;
	
	
	private JPanel contentPane;
	private JButton btnSave;
	private JButton btnDiscard;
	private JTextField txtDateStart;
	private JTextField txtTimeStart;
	private JTextField txtTimeEnd;
	private JLabel lblDateMm;
	private JLabel lblNewLabel;
	private JLabel lblToTime;
	private ButtonGroup btnTypeGroup;
	private JRadioButton rdbtnRepeating;
	private JRadioButton rdbtnSingle;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JLabel lblSaveLabel;
	private JTextField txtDateEnd;
	private JComboBox<String> recurBox;

	/**
	 * Create the frame.
	 */
	public DoctorSlotAdderProgramView(CalendarView cv) {
		
		this.cv = cv;
		//comment out initialize when running the Main DesignChallenge
		//initialize();
	}
	
	public void initialize() {
		setTitle("Doctor Slot Adder (Doctor Module)");
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		btnSave = new JButton("Save");
		btnSave.setForeground(new Color(30, 144, 255));
		btnSave.setBackground(new Color(30, 144, 255));
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//send input to control

					String type = null;
					if(rdbtnRepeating.isSelected()) {
						type = "Recur"+recurBox.getSelectedItem();
					}else if(rdbtnSingle.isSelected()) {
						type = "Single";
					}
					if(((CalendarProgramView)cv).getController().addSlots(cv.getDoctorName(), txtDateStart.getText(),
																		txtDateEnd.getText(), txtTimeStart.getText(), txtTimeEnd.getText(), type)) {
						lblSaveLabel.setText("<html><font color = green>Save Successful</font></html>");
					}else {
						lblSaveLabel.setText("<html><font color = red>Save Unsuccessful</font></html>");
					}

//				txtDateStart.setText(null);
				txtTimeStart.setText(null);
				txtTimeEnd.setText(null);
				//sets the save label to true
				lblSaveLabel.setVisible(true);
			}
		});
		btnSave.setBounds(132, 183, 72, 23);
		contentPane.add(btnSave);
		
		btnDiscard = new JButton("Clear");
		btnDiscard.setForeground(new Color(30, 144, 255));
		btnDiscard.setBackground(new Color(30, 144, 255));
		btnDiscard.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
//				txtDateStart.setText(null);
				txtTimeStart.setText(null);
				txtTimeEnd.setText(null);
//				setVisible(false);
				lblSaveLabel.setVisible(false);
			}
		});
		btnDiscard.setBounds(229, 183, 79, 23);
		contentPane.add(btnDiscard);
		
		txtDateStart = new JTextField();
		txtDateStart.setBounds(132, 77, 72, 20);
		contentPane.add(txtDateStart);
		txtDateStart.setColumns(10);
		
		txtTimeStart = new JTextField();
		txtTimeStart.setBounds(132, 122, 72, 20);
		contentPane.add(txtTimeStart);
		txtTimeStart.setColumns(10);
		
		txtTimeEnd = new JTextField();
		txtTimeEnd.setBounds(229, 122, 79, 20);
		contentPane.add(txtTimeEnd);
		txtTimeEnd.setColumns(10);
		
		lblDateMm = new JLabel("Date (MM/DD/YYYY):");
		lblDateMm.setBounds(11, 80, 111, 14);
		contentPane.add(lblDateMm);
		
		lblNewLabel = new JLabel("Time (24 hour): ");
		lblNewLabel.setBounds(37, 125, 93, 14);
		contentPane.add(lblNewLabel);
		
		lblToTime = new JLabel("to:");
		lblToTime.setBounds(210, 125, 20, 14);
		contentPane.add(lblToTime);
		
		rdbtnRepeating = new JRadioButton("Repeating");

		buttonGroup.add(rdbtnRepeating);
		rdbtnRepeating.setBounds(229, 47, 79, 23);
		contentPane.add(rdbtnRepeating);
		
		rdbtnSingle = new JRadioButton("Single");

		rdbtnSingle.setSelected(true);
		buttonGroup.add(rdbtnSingle);
		rdbtnSingle.setBounds(132, 47, 67, 23);
		contentPane.add(rdbtnSingle);
		
		//added the save successful button
		lblSaveLabel = new JLabel("Save Successful!");
		lblSaveLabel.setVisible(false);
		lblSaveLabel.setBounds(178, 217, 111, 14);
		contentPane.add(lblSaveLabel);
		
		JLabel label = new JLabel("to:");
		label.setBounds(210, 80, 20, 14);
		contentPane.add(label);
		
		txtDateEnd = new JTextField();
		txtDateEnd.setColumns(10);
		txtDateEnd.setBounds(229, 77, 79, 20);
		contentPane.add(txtDateEnd);
		
		recurBox = new JComboBox<>();
		recurBox.setBounds(315, 48, 72, 20);
		contentPane.add(recurBox);
		recurBox.addItem("Week");
		recurBox.addItem("Month");
		recurBox.addItem("Year");
		
	}
	
	public void clearInputs() {
		txtDateStart.setText(null);
		txtTimeStart.setText(null);
		txtTimeEnd.setText(null);
	}
	
	public void updateCurrentDate(int currentSelectedMonth,int currentSelectedDay, int currentSelectedYear) {
		txtDateStart.setText(currentSelectedMonth+1+"/"+currentSelectedDay+"/"+currentSelectedYear);
		txtDateEnd.setText(currentSelectedMonth+1+"/"+currentSelectedDay+"/"+currentSelectedYear);
	}
	
	public JTextField getTxtDateStart() {
		return txtDateStart;
	}

	@Override
	public void hideLabel() {
		// TODO Auto-generated method stub
		lblSaveLabel.setText(null);
	}
}
