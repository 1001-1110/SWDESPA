package DoctorView;

public interface DoctorLoginView {

}
