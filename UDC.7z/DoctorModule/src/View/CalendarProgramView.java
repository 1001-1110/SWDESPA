package View;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.*;
import javax.swing.text.DefaultCaret;

import Controller.CalendarControl;
import Controller.CalendarProgramControl;
import DoctorView.DoctorSlotAdderProgramView;
import DoctorView.DoctorSlotAdderView;
import DoctorView.DoctorSlotEditorProgramView;
import Entry.Entries;
import Entry.EntriesIterator;
import Entry.Entry;
import Entry.Notif;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.LineBorder;

public class CalendarProgramView implements CalendarView{

	private int yearBound, monthBound, dayBound, yearToday, monthToday, dayToday;
	private int currentSelectedMonth, currentSelectedDay, currentSelectedYear;
	private ArrayList<Integer> rowAssignment;
	
	CalendarControl cc;
	DayView dv;
	WeekView wv;
	AgendaView av;
	
        /**** Swing Components ****/
    public JLabel monthLabel;
	public JButton btnPrev, btnNext;
    public JComboBox<String> cmbYear;
	public JFrame frmMain;
	public Container pane;
	public JScrollPane scrollCalendarTable;
	public JPanel calendarPanel;
	
        /**** Calendar Table Components ***/
	public JTable calendarTable;
    public DefaultTableModel modelCalendarTable;
    private JPanel buttonPanel;
    private JPanel yearPanel;
    private JPanel interactPanel;
    private JPanel infoBorderPanel;
    private JPanel datePanel;
    private JLabel lblTitle;
    private JButton btnToday;
    private JLabel lblCurrentDate;
    private JLabel lblCurrentTime;
    private JButton btnTime;
    private JButton btnAgenda;
    private JPanel infoPanel;
    private JButton btnFreeUp;
    private JRadioButton rdbtnDay;
    private JRadioButton rdbtnWeek;
    
	private String doctorName;
	private DoctorSlotAdderView dsav;
	private JScrollPane notifScroll;
	private JButton btnClearNotifs;
	private JButton btnEdit;
	private DoctorSlotAdderView dsev;
	private JList<String> notifArea;
    
    public void attachController(CalendarControl cc) {
    	this.cc = cc;
    }
    
    @Override
	public void attachDoctorSlotAdderView(DoctorSlotAdderView dsav) {
		// TODO Auto-generated method stub
		this.dsav = dsav;
	}
    
    public void initialize() {
    	try {
			frmMain.setIconImage(ImageIO.read(new File("res/eye.png")));
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
    	dsav.initialize();
    	dsev.initialize();
		for (int i = yearBound-100; i <= yearBound+100; i++)
        {
			cmbYear.addItem(String.valueOf(i));
		}    	

		monthToday = monthBound;
		yearToday = yearBound;
    	
		btnToday.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GregorianCalendar cal = new GregorianCalendar();
				monthToday = cal.get(GregorianCalendar.MONTH);
				yearToday = cal.get(GregorianCalendar.YEAR);
				dayToday = cal.get(GregorianCalendar.DATE);
				refreshCalendar();
				cc.updateDateTitle(yearToday,monthToday,dayToday);
				refreshCalendar();
				cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
			}
		});//commented out and changed secondFilter.isSelected(), firstFilter.isSelected() to doctorName
//		firstFilter.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, secondFilter.isSelected(), firstFilter.isSelected(), rdbtnDay.isSelected(), rdbtnWeek.isSelected());
//			}
//		});
//		
//		secondFilter.addActionListener(new ActionListener() {
//			public void actionPerformed(ActionEvent e) {
//				cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, secondFilter.isSelected(), firstFilter.isSelected(), rdbtnDay.isSelected(), rdbtnWeek.isSelected());
//			}
//		}); 
		
		btnFreeUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				cc.refreshCalendarDays();
				cc.refreshCalendar(monthToday, yearToday);
				cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
			}
		});
		
		calendarTable.addMouseListener(new MouseAdapter() {  
		    public void mouseClicked(MouseEvent evt)  
		    {  
		        int col = calendarTable.getSelectedColumn();  
		        int row = calendarTable.getSelectedRow(); 
		        try {
			        if(modelCalendarTable.getValueAt(row, col) != null) {
			        	String day = modelCalendarTable.getValueAt(row, col).toString().replace("<html>","");
			            day = day.replace("<font color = \"red\">&#160","");
			            day = day.trim();
					    refreshCalendar();
				        cc.updateDateTitle(yearToday,monthToday,Integer.parseInt(day));
					    refreshCalendar();		
					    cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
			        }		        	
		        }catch(Exception e){}
		    }
		});

		rdbtnDay.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				av.updateCurrent(currentSelectedYear, currentSelectedMonth, currentSelectedDay, rdbtnWeek.isSelected());
				cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
				cc.refreshCalendar(monthToday, yearToday);
				if(infoPanel.getComponent(0) instanceof AgendaView)
					showAgendaView();
				else if(infoPanel.getComponent(0) instanceof DayView || infoPanel.getComponent(0) instanceof WeekView)
					showTimeView();
			}
		});

		rdbtnWeek.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				av.updateCurrent(currentSelectedYear, currentSelectedMonth, currentSelectedDay, rdbtnWeek.isSelected());
				cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
				cc.refreshCalendar(monthToday, yearToday);
				if(infoPanel.getComponent(0) instanceof AgendaView)
					showAgendaView();
				else if(infoPanel.getComponent(0) instanceof DayView || infoPanel.getComponent(0) instanceof WeekView)
					showTimeView();
			}
		});		
		
    	refreshCalendar();
		cc.updateDateTitle(yearToday, monthToday, dayToday);
		refreshCalendar();
		cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
		showAgendaView();
		frmMain.setVisible(false);
    }
    
    public void update() {
    	disableSelectButtons();
		infoPanel.revalidate();
		refreshView();
    }
    
	public void updateNotification(boolean success, String type) {

	}
    
    public void showTimeView() {
    	cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
		infoPanel.removeAll();
		if(rdbtnWeek.isSelected())
			infoPanel.add((Component) wv);
		else if(rdbtnDay.isSelected())
			infoPanel.add((Component) dv);
		infoPanel.revalidate();
		refreshView();    	
    }
    
    public void showAgendaView() {
    	cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
    	infoPanel.removeAll();
		infoPanel.add((Component) av);
		infoPanel.revalidate();
		refreshView();   	
    }
    
    public void refreshView() {
    	frmMain.repaint();
    }
    
    public void updateDateTitle(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay) {
    	this.currentSelectedYear = currentSelectedYear;
    	this.currentSelectedMonth = currentSelectedMonth;
    	this.currentSelectedDay = currentSelectedDay;
    	av.updateCurrent(currentSelectedYear, currentSelectedMonth, currentSelectedDay, rdbtnWeek.isSelected());
    	dv.updateCurrent(currentSelectedYear, currentSelectedMonth, currentSelectedDay);
    	wv.updateCurrent(currentSelectedYear, currentSelectedMonth, currentSelectedDay);
    	String currentDate = new String();
    	currentDate += monthLabel.getText();
    	currentDate += " "+currentSelectedDay;
    	currentDate += ", "+currentSelectedYear;
    	lblCurrentDate.setText(currentDate);
    }
    
    public void updateTime(String time) {
    	lblCurrentTime.setText(time);
		infoPanel.revalidate();
		refreshView();  
    }

    public void refreshCalendar() {
    	cc.refreshCalendar(monthToday, yearToday);
    }    
    
    public void refreshCalendar(int month, int year, ArrayList<Integer> days){
		String[] months =  {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
		int nod, som, i, j;
			
		btnPrev.setEnabled(true);
		btnNext.setEnabled(true);
		
		btnPrev.setContentAreaFilled(false);
		
		if (month == 0 && year <= yearBound-100)
                    btnPrev.setEnabled(false);
		if (month == 11 && year >= yearBound+100)
                    btnNext.setEnabled(false);
                
		monthLabel.setText(months[month]);

		cmbYear.setSelectedItem(""+year);
		
		for (i = 0; i < 6; i++)
			for (j = 0; j < 7; j++)
				modelCalendarTable.setValueAt(null, i, j);
		
		GregorianCalendar cal = new GregorianCalendar(year, month, 1);
		nod = cal.getActualMaximum(GregorianCalendar.DAY_OF_MONTH);
		som = cal.get(GregorianCalendar.DAY_OF_WEEK);
		
		for (i = 1; i <= nod; i++){
			int row = new Integer((i+som-2)/7);
			int column  =  (i+som-2)%7;
			boolean isMarked = false;
			for(int x = 0 ; x < days.size() && !isMarked; x++) {
				if(days.get(x) == i) {
					modelCalendarTable.setValueAt("<html><font color = \"red\">&#160 "+i, row, column);
					isMarked = true;
				}
			}
			if(!isMarked)
				modelCalendarTable.setValueAt("  "+i, row, column);
        }
		Calendar c = new GregorianCalendar(currentSelectedYear, currentSelectedMonth, currentSelectedDay);
		List<String> selectedDates = new ArrayList<>();
		if(rdbtnWeek.isSelected())
			for(int x = 0 ; x < 7 ; x++) {
				selectedDates.add(c.get(Calendar.YEAR)+"-"+c.get(Calendar.MONTH)+" "+c.get(Calendar.DATE));
				c.add(Calendar.DATE, 1);
			}
		else if(rdbtnDay.isSelected())
			selectedDates.add(currentSelectedYear+"-"+currentSelectedMonth+" "+currentSelectedDay);
		calendarTable.setDefaultRenderer(calendarTable.getColumnClass(0), new TableRenderer(month, year, selectedDates));
		calendarTable.clearSelection();
    }
    
    public void showNotif(String message) {
    	JOptionPane.showMessageDialog(null, message);
    }
    
    public void showErrorNotif(String message) {
    	JOptionPane.showMessageDialog(null, message, "Invalid",JOptionPane.ERROR_MESSAGE);
    }
    
	public CalendarProgramView()
        {
		
		try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
		catch (Exception e) {}
                
		frmMain = new JFrame ("Productivity Tool");
		frmMain.getContentPane().setForeground(new Color(0, 255, 255));
		frmMain.getContentPane().setBackground(new Color(30, 144, 255));
		frmMain.setTitle("The Eye Company (Doctor Module)");
                frmMain.setSize(1000, 600);
		pane = frmMain.getContentPane();
		pane.setLayout(null);
		frmMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		modelCalendarTable = new DefaultTableModel()
                {
                    public boolean isCellEditable(int rowIndex, int mColIndex)
                    {
                        return false;
                    }
                };
                
		frmMain.setResizable(false);
		
		GregorianCalendar cal = new GregorianCalendar();
		dayBound = cal.get(GregorianCalendar.DAY_OF_MONTH);
		monthBound = cal.get(GregorianCalendar.MONTH);
		yearBound = cal.get(GregorianCalendar.YEAR);
		monthToday = monthBound; 
		yearToday = yearBound;
		dayToday = dayBound;
		
		String[] headers = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"}; //All headers
		for (int i=0; i<7; i++){
			modelCalendarTable.addColumn(headers[i]);
		}
		
		notifScroll = new JScrollPane();
		notifScroll.setBounds(24, 412, 291, 137);
		frmMain.getContentPane().add(notifScroll);
		
		notifArea = new JList<>();
		notifArea.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		notifScroll.setViewportView(notifArea);
		
		interactPanel = new JPanel();
		interactPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		interactPanel.setBounds(10, 11, 974, 81);
		frmMain.getContentPane().add(interactPanel);
		
		lblTitle = new JLabel("");
		lblTitle.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		btnToday = new JButton("Go to Today");
		btnToday.setForeground(new Color(30, 144, 255));
		btnToday.setBackground(new Color(30, 144, 255));

		
		lblCurrentDate = new JLabel();
		lblCurrentDate.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		btnTime = new JButton("Time");
		btnTime.setForeground(new Color(30, 144, 255));
		btnTime.setBackground(new Color(30, 144, 255));
		btnTime.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showTimeView();
			}
		});
		
		btnAgenda = new JButton("Agenda");
		btnAgenda.setBackground(new Color(30, 144, 255));
		btnAgenda.setForeground(new Color(30, 144, 255));
		btnAgenda.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showAgendaView();
			}
		});
		
		btnFreeUp = new JButton("Free Up");
		btnFreeUp.setForeground(new Color(30, 144, 255));
		btnFreeUp.setBackground(new Color(30, 144, 255));
		btnFreeUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int id[] = {av.getSelectedEntry()};
				if(cc.freeUpSlots(id)) {
					showNotif("Deleted");
				}else {
					showErrorNotif("Cannot delete.");
				}
			}
		});
		
		ButtonGroup selectView = new ButtonGroup();
		
		rdbtnDay = new JRadioButton("View by day");
		rdbtnWeek = new JRadioButton("View by week");
		
		selectView.add(rdbtnDay);
		selectView.add(rdbtnWeek);
		
		rdbtnDay.setSelected(true);
		
		lblCurrentTime = new JLabel("");
		
		btnEdit = new JButton("Edit");
		btnEdit.setForeground(new Color(30, 144, 255));
		btnEdit.setBackground(new Color(30, 144, 255));
		btnEdit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dsev.updateCurrentDate(currentSelectedMonth, currentSelectedDay, currentSelectedYear);
				((DoctorSlotEditorProgramView) dsev).hideLabel();
				((DoctorSlotEditorProgramView) dsev).setVisible(true);
			}
		});
		btnEdit.setEnabled(false);
		GroupLayout gl_interactPanel = new GroupLayout(interactPanel);
		gl_interactPanel.setHorizontalGroup(
			gl_interactPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_interactPanel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_interactPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_interactPanel.createSequentialGroup()
							.addComponent(lblTitle)
							.addGap(18)
							.addComponent(btnToday))
						.addGroup(gl_interactPanel.createSequentialGroup()
							.addComponent(rdbtnDay)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(rdbtnWeek)))
					.addGap(81)
					.addGroup(gl_interactPanel.createParallelGroup(Alignment.LEADING)
						.addComponent(lblCurrentTime, GroupLayout.PREFERRED_SIZE, 117, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblCurrentDate, GroupLayout.PREFERRED_SIZE, 173, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 303, Short.MAX_VALUE)
					.addGroup(gl_interactPanel.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(btnEdit, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnFreeUp, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addGap(51)
					.addGroup(gl_interactPanel.createParallelGroup(Alignment.LEADING, false)
						.addComponent(btnAgenda, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnTime, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_interactPanel.setVerticalGroup(
			gl_interactPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_interactPanel.createSequentialGroup()
					.addGroup(gl_interactPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_interactPanel.createSequentialGroup()
							.addGap(22)
							.addComponent(lblCurrentDate, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblCurrentTime, GroupLayout.DEFAULT_SIZE, 17, Short.MAX_VALUE))
						.addGroup(gl_interactPanel.createSequentialGroup()
							.addContainerGap()
							.addGroup(gl_interactPanel.createParallelGroup(Alignment.TRAILING)
								.addComponent(lblTitle)
								.addGroup(gl_interactPanel.createParallelGroup(Alignment.LEADING)
									.addGroup(gl_interactPanel.createParallelGroup(Alignment.BASELINE)
										.addComponent(btnTime)
										.addComponent(btnEdit))
									.addComponent(btnToday)))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(gl_interactPanel.createParallelGroup(Alignment.BASELINE)
								.addComponent(btnAgenda)
								.addComponent(btnFreeUp)
								.addComponent(rdbtnDay)
								.addComponent(rdbtnWeek))))
					.addGap(11))
		);
		interactPanel.setLayout(gl_interactPanel);
		
		infoBorderPanel = new JPanel();
		infoBorderPanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		infoBorderPanel.setBounds(338, 103, 646, 463);
		frmMain.getContentPane().add(infoBorderPanel);
		
		infoPanel = new JPanel();
		infoPanel.setLayout(null);
		GroupLayout gl_infoBorderPanel = new GroupLayout(infoBorderPanel);
		gl_infoBorderPanel.setHorizontalGroup(
			gl_infoBorderPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_infoBorderPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(infoPanel, GroupLayout.DEFAULT_SIZE, 624, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_infoBorderPanel.setVerticalGroup(
			gl_infoBorderPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_infoBorderPanel.createSequentialGroup()
					.addGap(5)
					.addComponent(infoPanel, GroupLayout.DEFAULT_SIZE, 445, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		infoBorderPanel.setLayout(gl_infoBorderPanel);
		
		datePanel = new JPanel();
		datePanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		datePanel.setBounds(10, 98, 318, 463);
		frmMain.getContentPane().add(datePanel);
		
		calendarTable = new JTable(modelCalendarTable);
		calendarTable.clearSelection();

		scrollCalendarTable = new JScrollPane(calendarTable);
		calendarPanel = new JPanel(null);
        calendarPanel.setBorder(null);
        
        calendarTable.getParent().setBackground(calendarTable.getBackground()); //Set background
        
                calendarTable.getTableHeader().setResizingAllowed(false);
                calendarTable.getTableHeader().setReorderingAllowed(false);
                
                        calendarTable.setColumnSelectionAllowed(true);
                        calendarTable.setRowSelectionAllowed(true);
                        calendarTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
                        
                                calendarTable.setRowHeight(29);
                                
                                JButton btnCreate = new JButton("ADD NEW SLOT");
                                btnCreate.addActionListener(new ActionListener() {
                                	public void actionPerformed(ActionEvent e) {
                                		((DoctorSlotAdderProgramView) dsav).setVisible(true);
                                		dsav.updateCurrentDate(currentSelectedMonth, currentSelectedDay, currentSelectedYear);
                                	}
                                });
                                btnCreate.setForeground(new Color(30, 144, 255));
                                btnCreate.setBackground(new Color(30, 144, 255));
                                
                                buttonPanel = new JPanel();
                                
                                yearPanel = new JPanel();
                                
                                JLabel lblView = new JLabel("Notification");
                                lblView.setFont(new Font("Tahoma", Font.BOLD, 18));
                                
                                btnClearNotifs = new JButton("Clear Notifs");
                                btnClearNotifs.setForeground(new Color(30, 144, 255));
                                btnClearNotifs.setBackground(new Color(30, 144, 255));
                                btnClearNotifs.addActionListener(new ActionListener() {
                                	public void actionPerformed(ActionEvent e) {
                                		if(cc.deleteNotifs()) {
                                			JOptionPane.showMessageDialog(frmMain, "Notifs cleared.", "Notifs cleared",JOptionPane.INFORMATION_MESSAGE);
                                		}else {
                                			JOptionPane.showMessageDialog(frmMain, "Notifs not cleared", "Notifs not cleared",JOptionPane.ERROR_MESSAGE);
                                		}
                                	}
                                });
                                GroupLayout gl_calendarPanel = new GroupLayout(calendarPanel);
                                gl_calendarPanel.setHorizontalGroup(
                                	gl_calendarPanel.createParallelGroup(Alignment.LEADING)
                                		.addGroup(gl_calendarPanel.createSequentialGroup()
                                			.addGap(36)
                                			.addComponent(btnCreate, GroupLayout.PREFERRED_SIZE, 224, GroupLayout.PREFERRED_SIZE)
                                			.addContainerGap(41, Short.MAX_VALUE))
                                		.addGroup(gl_calendarPanel.createSequentialGroup()
                                			.addContainerGap()
                                			.addGroup(gl_calendarPanel.createParallelGroup(Alignment.TRAILING)
                                				.addComponent(scrollCalendarTable, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 270, Short.MAX_VALUE)
                                				.addGroup(gl_calendarPanel.createSequentialGroup()
                                					.addComponent(yearPanel, GroupLayout.PREFERRED_SIZE, 143, Short.MAX_VALUE)
                                					.addPreferredGap(ComponentPlacement.RELATED)
                                					.addComponent(buttonPanel, GroupLayout.PREFERRED_SIZE, 121, GroupLayout.PREFERRED_SIZE)))
                                			.addGap(31))
                                		.addGroup(gl_calendarPanel.createSequentialGroup()
                                			.addComponent(lblView)
                                			.addPreferredGap(ComponentPlacement.RELATED, 98, Short.MAX_VALUE)
                                			.addComponent(btnClearNotifs)
                                			.addGap(19))
                                );
                                gl_calendarPanel.setVerticalGroup(
                                	gl_calendarPanel.createParallelGroup(Alignment.LEADING)
                                		.addGroup(gl_calendarPanel.createSequentialGroup()
                                			.addComponent(btnCreate, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
                                			.addPreferredGap(ComponentPlacement.RELATED)
                                			.addGroup(gl_calendarPanel.createParallelGroup(Alignment.LEADING, false)
                                				.addComponent(buttonPanel, 0, 0, Short.MAX_VALUE)
                                				.addComponent(yearPanel, GroupLayout.PREFERRED_SIZE, 21, Short.MAX_VALUE))
                                			.addPreferredGap(ComponentPlacement.RELATED)
                                			.addComponent(scrollCalendarTable, GroupLayout.PREFERRED_SIZE, 202, GroupLayout.PREFERRED_SIZE)
                                			.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                			.addGroup(gl_calendarPanel.createParallelGroup(Alignment.TRAILING)
                                				.addComponent(lblView)
                                				.addComponent(btnClearNotifs)))
                                );
                                cmbYear = new JComboBox();
                                
                                JPanel monthPanel = new JPanel();
                                
                                        monthLabel = new JLabel ("January");
                                        GroupLayout gl_monthPanel = new GroupLayout(monthPanel);
                                        gl_monthPanel.setHorizontalGroup(
                                            gl_monthPanel.createParallelGroup(Alignment.LEADING)
                                                .addGroup(gl_monthPanel.createSequentialGroup()
                                                    .addContainerGap()
                                                    .addComponent(monthLabel, GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE))
                                        );
                                        gl_monthPanel.setVerticalGroup(
                                            gl_monthPanel.createParallelGroup(Alignment.LEADING)
                                                .addGroup(gl_monthPanel.createSequentialGroup()
                                                    .addComponent(monthLabel)
                                                    .addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        );
                                        monthPanel.setLayout(gl_monthPanel);
                                        GroupLayout gl_yearPanel = new GroupLayout(yearPanel);
                                        gl_yearPanel.setHorizontalGroup(
                                            gl_yearPanel.createParallelGroup(Alignment.LEADING)
                                                .addGroup(gl_yearPanel.createSequentialGroup()
                                                    .addComponent(monthPanel, GroupLayout.PREFERRED_SIZE, 67, GroupLayout.PREFERRED_SIZE)
                                                    .addPreferredGap(ComponentPlacement.RELATED)
                                                    .addComponent(cmbYear, GroupLayout.PREFERRED_SIZE, 63, GroupLayout.PREFERRED_SIZE)
                                                    .addContainerGap(32, Short.MAX_VALUE))
                                        );
                                        gl_yearPanel.setVerticalGroup(
                                            gl_yearPanel.createParallelGroup(Alignment.LEADING)
                                                .addGroup(gl_yearPanel.createSequentialGroup()
                                                    .addGroup(gl_yearPanel.createParallelGroup(Alignment.TRAILING, false)
                                                        .addComponent(monthPanel, Alignment.LEADING, 0, 0, Short.MAX_VALUE)
                                                        .addComponent(cmbYear, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 17, Short.MAX_VALUE))
                                                    .addContainerGap())
                                        );
                                        yearPanel.setLayout(gl_yearPanel);
                                        cmbYear.addActionListener(new cmbYear_Action());
                                        btnPrev = new JButton ("<");
                                        btnPrev.setBorder(new LineBorder(new Color(0, 0, 0)));
                                        
                                        btnPrev.addActionListener(new btnPrev_Action());
                                        btnNext = new JButton (">");
                                        btnNext.setBorder(new LineBorder(new Color(0, 0, 0)));
                                        btnNext.setContentAreaFilled(false);
                                        GroupLayout gl_buttonPanel = new GroupLayout(buttonPanel);
                                        gl_buttonPanel.setHorizontalGroup(
                                            gl_buttonPanel.createParallelGroup(Alignment.TRAILING)
                                                .addGroup(gl_buttonPanel.createSequentialGroup()
                                                    .addGap(2)
                                                    .addComponent(btnPrev, GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
                                                    .addPreferredGap(ComponentPlacement.RELATED)
                                                    .addComponent(btnNext, GroupLayout.PREFERRED_SIZE, 53, GroupLayout.PREFERRED_SIZE)
                                                    .addContainerGap())
                                        );
                                        gl_buttonPanel.setVerticalGroup(
                                            gl_buttonPanel.createParallelGroup(Alignment.TRAILING)
                                                .addGroup(Alignment.LEADING, gl_buttonPanel.createSequentialGroup()
                                                    .addGroup(gl_buttonPanel.createParallelGroup(Alignment.BASELINE)
                                                        .addComponent(btnPrev, GroupLayout.PREFERRED_SIZE, 15, Short.MAX_VALUE)
                                                        .addComponent(btnNext, GroupLayout.PREFERRED_SIZE, 15, GroupLayout.PREFERRED_SIZE))
                                                    .addContainerGap())
                                        );
                                        buttonPanel.setLayout(gl_buttonPanel);
                                        btnNext.addActionListener(new btnNext_Action());
                                        calendarPanel.setLayout(gl_calendarPanel);
		GroupLayout gl_datePanel = new GroupLayout(datePanel);
		gl_datePanel.setHorizontalGroup(
			gl_datePanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_datePanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(calendarPanel, GroupLayout.PREFERRED_SIZE, 301, Short.MAX_VALUE)
					.addGap(5))
		);
		gl_datePanel.setVerticalGroup(
			gl_datePanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_datePanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(calendarPanel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(150, Short.MAX_VALUE))
		);
		datePanel.setLayout(gl_datePanel);
		
		modelCalendarTable.setColumnCount(7);
		modelCalendarTable.setRowCount(6);
		
	}

	public void appendNotification(Entries notifs) {
		EntriesIterator ei = notifs.getIterator();
		String[] notifications = new String[notifs.size()];
		Calendar currentTime = new GregorianCalendar();
		rowAssignment = new ArrayList<>();
		
		while(ei.hasNext()) {
			Entry notif = ei.next();
			rowAssignment.add(notif.getId());
			if(notif.getDateTo() == null) {
				notifications[ei.getPos()-1] = ((Notif) notif).getClient()+" has cancelled their "+notif.getDurationFrom()+" booking.";
			}else {
				long timeDifference = ((notif.getDateFrom().getTimeInMillis() - currentTime.getTimeInMillis()) /1000)/60;
				if(timeDifference > 0) {
					notifications[ei.getPos()-1] = "Reminder: Booking with "+((Notif) notif).getClient()+" in "+timeDifference+" minutes.";
				}else {
					notifications[ei.getPos()-1] = "<html><s>Reminder: Booking with "+((Notif) notif).getClient();
				}

			}
		}
		
		notifScroll.setAutoscrolls(true);
		
		notifArea.setListData(notifications);
	}
	private void disableSelectButtons() {
		btnFreeUp.setEnabled(false);
		btnEdit.setEnabled(false);
	}

	public void enableSelectButtons() {
		btnFreeUp.setEnabled(true);
		btnEdit.setEnabled(true);
	}	
	
	public void attachDayView(DayView dv) {
       	this.dv = dv;
	}

	public void attachWeekView(WeekView wv) {
       	this.wv = wv;
	}	
	
	public void attachAgendaView(AgendaView av) {
       	this.av = av;
	}	
	
	class btnPrev_Action implements ActionListener
        {
		public void actionPerformed (ActionEvent e)
                {
			if (monthToday == 0)
                        {
				monthToday = 11;
				yearToday -= 1;
			}
			else
                        {
				monthToday -= 1;
			}				
			refreshCalendar();
			cc.refreshCalendarDays();
			refreshCalendar();
		}
	}
	class btnNext_Action implements ActionListener
        {
		public void actionPerformed (ActionEvent e)
                {
			if (monthToday == 11)
                        {
				monthToday = 0;
				yearToday += 1;
			}
			else
                        {
				monthToday += 1;
			}				
			refreshCalendar();
			cc.refreshCalendarDays();
			refreshCalendar();
		}
	}
	class cmbYear_Action implements ActionListener
        {
		public void actionPerformed (ActionEvent e)
                {
			if (cmbYear.getSelectedItem() != null)
                        {
				String b = cmbYear.getSelectedItem().toString();
				yearToday = Integer.parseInt(b);
				refreshCalendar();
				cc.refreshCalendarDays();
				refreshCalendar();
			}
		}
	}
	public JLabel getLblTitle() {
		return lblTitle;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
		this.cc.setUsername(doctorName);
		showAgendaView();	
	}
	
	public void updateViews() {
		cc.updateViews(currentSelectedYear, currentSelectedMonth, currentSelectedDay, doctorName, rdbtnDay.isSelected(), rdbtnWeek.isSelected());
	}
	
	public String getDoctorName() {
		return this.doctorName;
	}
	
	public CalendarControl getController() {
		// TODO Auto-generated method stub
		return cc;
	}
	
	public AgendaView getAgendaView() {
		return av;
	}

	@Override
	public void attachDoctorSlotEditorView(DoctorSlotAdderView dsev) {
		// TODO Auto-generated method stub
		this.dsev = dsev;
	}
}
