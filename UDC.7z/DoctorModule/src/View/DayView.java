package View;

public interface DayView {
	
	public abstract void updateCurrent(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay);
	
}
