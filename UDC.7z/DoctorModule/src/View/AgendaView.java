package View;
import java.util.List;

public interface AgendaView{
	
	public abstract int getSelectedEntry();

	public abstract void updateCurrent(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay, boolean b);
	
}
