
import Controller.CalendarControl;
import Controller.CalendarProgramControl;
import Database.DBLoginView;
import Model.CalendarModel;
import Model.CalendarProgramModel;
import View.AgendaProgramView;
import View.AgendaProgramView2;
import View.AgendaView;
import View.CalendarProgramView;
import View.CalendarView;
import View.ObserverView;

public class ClientModule{

    public static void main(String[] args) {
        // TODO code application logic here
    	DBLoginView dl = new DBLoginView();
    	
    	while(dl.login());
    	
    	CalendarView cpv = new CalendarProgramView();
        AgendaView apv = new AgendaProgramView(cpv);
        AgendaView apv2 = new AgendaProgramView2(cpv);
        CalendarModel cpm = new CalendarProgramModel();
        CalendarControl cpc = new CalendarProgramControl();
        cpv.attachController(cpc);
        cpv.attachAgendaView(apv);
        cpv.attachAgendaView2(apv2);
        cpm.attachView(cpv);
        cpc.attachModel(cpm);     
        cpm.attachObserver((ObserverView) apv);
        cpm.attachObserver((ObserverView) apv2);
        cpv.initialize();
        cpv.refreshView();
        cpm.timeCheck();	
    	//com.mysql.jdbc.Driver
    	//jdbc:mysql://127.0.0.1:3306/
    	//root (username)
    	//july (password)
    	//SWDESPA (database)
        //	private String DRIVER_NAME = "com.mysql.jdbc.Driver";
    	//private String URL = "jdbc:mysql://112.205.74.172:3306/";
    	//private String USERNAME = "superuser";
    	//private String PASSWORD = "sophia";
    	//private String DATABASE = "swdespa";
    }
    
}
