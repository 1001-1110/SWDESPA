package View;

public interface AgendaView{
	
	public abstract int getSelectedOccasion();

	public abstract void updateCurrent(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay,
			boolean selected);
	
}
