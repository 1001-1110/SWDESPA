package View;

import javax.swing.*;
import javax.swing.table.*;

import Entry.Book;
import Entry.Entries;
import Entry.EntriesCollection;
import Entry.EntriesIterator;
import Entry.Slot;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.GroupLayout.Alignment;
import javax.swing.border.LineBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AgendaProgramView2 extends JPanel implements AgendaView, ObserverView{
	
	CalendarView cv;
	
	List<Integer> rowAssignment;
	int currentRow;
	
	JScrollPane scrollCalendarTable;    
	
        /**** Calendar Table Components ***/
	public JTable calendarTable;
    public DefaultTableModel modelCalendarTable;
    
    public void deselect() {
    	//currentRow = -1;
		calendarTable.setDefaultRenderer(calendarTable.getColumnClass(0), new InfoTableRenderer(calendarTable.getSelectedRow()));    	
    }
    
    // WHERE YOU WILL IMPLEMENT HOW THE DATA IS DISPLAYED
    public void update(Entries slots, Entries books) {  	
    	//rowAssignment = where the IDs reside for referencing later on
		rowAssignment = new ArrayList<>();
		
		EntriesIterator eiBooks = books.getIterator();
		EntriesIterator eiSlots = slots.getIterator();

		Entries newSet = new EntriesCollection();
		while(eiBooks.hasNext()) { //Deleting Bookings
			Book book = (Book) eiBooks.next();
			//System.out.println(currentRow);
			//System.out.println(rowAssignment);
			if(cv.getUser() != null) {
				if(cv.getUser().equals(book.getClient())) {
					newSet.add(book);
				}
			}
		}		
		
		eiBooks = newSet.getIterator();
		books = newSet;
		
        modelCalendarTable.setRowCount(books.size());
		while(eiBooks.hasNext()) {
			Book book = (Book) eiBooks.next();
			//System.out.println(currentRow);
			//System.out.println(rowAssignment);
			rowAssignment.add(book.getId());
			modelCalendarTable.setValueAt("<html>"+book.getDurationFrom().substring(0,16)+" to "+book.getDurationTo().substring(0,16)+"</html>", eiBooks.getPos()-1, 0);
			eiSlots.reset();
			while(eiSlots.hasNext()) {
				Slot slot = (Slot) eiSlots.next();
				if(slot.getId() == book.getSlotsID()) {
					modelCalendarTable.setValueAt("<html>"+slot.getDoctor()+"</html>", eiBooks.getPos()-1, 1);
				}
			}
		}
    }
    
    public int getSelectedOccasion() {
    	System.out.println(currentRow);
    	System.out.println(rowAssignment.size());
    	return rowAssignment.get(currentRow);
    }
    
//    public String getDoctor(int index) {
//		String doc = "";
//		return doc;
//	}
//    
    
	public AgendaProgramView2(CalendarView cv){
		setBackground(new Color(95, 158, 160));
		
		setBounds(0,0,620,440);
		
		this.cv =  cv;
		
		try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
		catch (Exception e) {}
        
		modelCalendarTable = new DefaultTableModel()
                {
                    public boolean isCellEditable(int rowIndex, int mColIndex)
                    {
                        return false;
                    }
                };      
                
		calendarTable = new JTable(modelCalendarTable);
		calendarTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				currentRow = (int) calendarTable.getSelectedRow();
				calendarTable.setDefaultRenderer(calendarTable.getColumnClass(0), new InfoTableRenderer(calendarTable.getSelectedRow()));
				cv.enableSelectButtons();
				calendarTable.clearSelection();
				calendarTable.repaint();
				
			}
		});
                
		scrollCalendarTable = new JScrollPane(calendarTable);
		scrollCalendarTable.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		
		this.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		calendarTable.getParent().setBackground(calendarTable.getBackground()); //Set background

		calendarTable.getTableHeader().setResizingAllowed(false);
		calendarTable.getTableHeader().setReorderingAllowed(false);

		calendarTable.setColumnSelectionAllowed(true);
		calendarTable.setRowSelectionAllowed(true);
		calendarTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

		calendarTable.setRowHeight(20);
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollCalendarTable, GroupLayout.DEFAULT_SIZE, 428, Short.MAX_VALUE)
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollCalendarTable, GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
					.addContainerGap())
		);
		setLayout(groupLayout);
		modelCalendarTable.addColumn("Time");
		modelCalendarTable.addColumn("Doctor");

		calendarTable.setDefaultRenderer(calendarTable.getColumnClass(0), new InfoTableRenderer(calendarTable.getSelectedRow()));
	}

	public void setFilters(boolean firstFilter, boolean secondFilter) {
		
	}

	@Override
	public void updateCurrent(int currentSelectedYear, int currentSelectedMonth, int currentSelectedDay,
			boolean selected) {
		// TODO Auto-generated method stub
		
	}

}
